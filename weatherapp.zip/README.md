# Getting Started with Create React App

With The Weather Forecasting app user can search locations by city name and observe the weather.
The app is developed using React.js, material-UI and Laravel.

## Install the Packages

Install the packages using the command "npm install"

## Available Scripts

To run this project directory, run "npm start" in terminal..
Runs the app in development mode..
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

## Used libraries

react-js
material-ui
Check packages.json for details
Laravel

